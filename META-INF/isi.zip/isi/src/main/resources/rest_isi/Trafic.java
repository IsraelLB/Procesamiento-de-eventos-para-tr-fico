package rest_isi;

import javax.ws.rs.GET;

import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces; 
import javax.ws.rs.core.MediaType;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

@Path("/Trafic")
public class Trafic {
	
	private static int numberOfTraficEvents = 0;
	private static String multas="MULTAS:\n";
	private static String accidentes="ACCIDENTES:\n";

	@GET 
	@Produces(MediaType.TEXT_PLAIN)
	public String sayIsWorking() {
		return "Trafic is working.";
	} 
	
	@POST 
	@Produces(MediaType.TEXT_PLAIN)
	@Path("/AddTraficEvent")
	public String addTemperatureEvent(String event) {
		numberOfTraficEvents = numberOfTraficEvents + 1;
		Pattern pattern = Pattern.compile("\\{([^{}]+)\\}");
        Matcher matcher = pattern.matcher(event);

        // Verificar si se encuentra una coincidencia y extraer el contenido entre corchetes
        if (matcher.find()) {
            String contenidoEntreCorchetes = matcher.group(1);
            if(contenidoEntreCorchetes.startsWith("VelocidadMaximaPermitida")) {
            	multas= multas + "\n" + contenidoEntreCorchetes+ "\n";
            }
            if(contenidoEntreCorchetes.startsWith("FechayHora")){
           		accidentes= accidentes + "\n" + contenidoEntreCorchetes+ "\n";
           	}
            }
            
		return "Trafic event added correctly.";
	}
	
	@GET 
	@Produces(MediaType.TEXT_PLAIN)
	@Path("/NumberOfTraficEvents")
	public String getNumberOfTemperatureEvents() {
		return  numberOfTraficEvents + " events have happened.";
	} 
	@GET 
	@Produces(MediaType.TEXT_PLAIN)
	@Path("/multas")
	public String getmultas() {
		return  multas;
	} 
	@GET 
	@Produces(MediaType.TEXT_PLAIN)
	@Path("/accidentes")
	public String getaccidentes() {
		return  accidentes;
	} 
}